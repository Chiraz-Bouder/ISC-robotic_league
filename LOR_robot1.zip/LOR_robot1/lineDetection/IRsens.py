# Import necessary modules
from gpiozero import Robot, LineSensor
from time import sleep

# Initialize the robot and IR sensors
robot = Robot(left=(7, 8), right=(9, 10))
left_sensor = LineSensor(17)
right_sensor = LineSensor(27)
speed = 0.65  # Motor speed

# Function to control motor speeds based on IR sensor values
def motor_speed():
    while True:
        left_detect = int(left_sensor.value)
        right_detect = int(right_sensor.value)

        # Stage 1: Both sensors on the line
        if left_detect == 0 and right_detect == 0:
            left_mot = 1
            right_mot = 1

        # Stage 2: Right sensor off the line
        if left_detect == 0 and right_detect == 1:
            left_mot = -1

        # Stage 3: Left sensor off the line
        if left_detect == 1 and right_detect == 0:
            right_mot = -1

        # Yield motor speeds
        yield (right_mot, left_mot, speed)

# Set the robot's source to the motor_speed generator function
robot.source = motor_speed()

# Run the robot for 60 seconds
sleep(60)

# Stop the robot and perform cleanup
robot.stop()
robot.source = None
robot.close()
left_sensor.close()
right_sensor.close()
